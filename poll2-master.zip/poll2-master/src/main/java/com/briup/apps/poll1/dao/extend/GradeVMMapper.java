package com.briup.apps.poll1.dao.extend;

import java.util.List;

import com.briup.apps.poll1.bean.extend.GradeVM;
import com.briup.apps.poll1.bean.Grade;

public interface GradeVMMapper {

	
	List<GradeVM> selectAll();
	
}
